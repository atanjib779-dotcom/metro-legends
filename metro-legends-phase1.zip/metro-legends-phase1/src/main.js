import * as THREE from 'three';
import './style.css';
import { CityWorld } from './world.js';
import { Player } from './player.js';
import { GameControls } from './controls.js';

const $ = (id) => document.getElementById(id);
const canvas = $('game-canvas');
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(62, window.innerWidth / window.innerHeight, 0.1, 320);
camera.position.set(6, 5.0, 20);

const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.65));
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.08;

const world = new CityWorld(scene);
const player = new Player(scene, world.colliders);
const controls = new GameControls(canvas, {
  joystickBase: $('joystick-base'),
  joystickThumb: $('joystick-thumb'),
  jumpButton: $('jump-button'),
  runButton: $('run-button'),
});

const state = {
  mode: 'menu',
  previousPanel: 'main',
  lastFrame: performance.now(),
  clock: new THREE.Clock(),
};

function updateCamera(delta) {
  const distance = controls.cameraDistance;
  const pitch = controls.cameraPitch;
  const horizontal = Math.cos(pitch) * distance;
  const vertical = Math.sin(pitch) * distance;
  const target = new THREE.Vector3(player.position.x, player.position.y + 1.52, player.position.z);
  const desired = new THREE.Vector3(
    player.position.x + Math.sin(controls.cameraYaw) * horizontal,
    player.position.y + 1.8 + vertical,
    player.position.z + Math.cos(controls.cameraYaw) * horizontal,
  );
  camera.position.lerp(desired, 1 - Math.exp(-8.5 * delta));
  camera.lookAt(target);
}

function showToast(message) {
  const toast = $('toast');
  toast.textContent = message;
  toast.classList.remove('hidden');
  window.clearTimeout(showToast.timer);
  showToast.timer = window.setTimeout(() => toast.classList.add('hidden'), 2200);
}

function resetPlayer() {
  player.position.set(6, 0, 12);
  player.velocity.set(0, 0, 0);
  player.verticalVelocity = 0;
  player.grounded = true;
  player.group.position.copy(player.position);
  player.group.rotation.y = 0;
  controls.cameraYaw = 0;
  controls.cameraPitch = 0.28;
  controls.cameraDistance = 7.5;
}

function startGame() {
  resetPlayer();
  state.mode = 'running';
  $('main-menu').classList.add('hidden');
  $('pause-menu').classList.add('hidden');
  $('hud').classList.remove('hidden');
  $('mobile-controls').classList.toggle('hidden', !controls.isCoarse);
  showToast('শহরে স্বাগতম! ঘুরে দেখো।');
  canvas.focus?.();
}

function pauseGame() {
  if (state.mode !== 'running') return;
  state.mode = 'paused';
  $('pause-menu').classList.remove('hidden');
  $('mobile-controls').classList.add('hidden');
}

function resumeGame() {
  if (state.mode !== 'paused') return;
  state.mode = 'running';
  $('pause-menu').classList.add('hidden');
  $('mobile-controls').classList.toggle('hidden', !controls.isCoarse);
}

function returnToMenu() {
  state.mode = 'menu';
  $('pause-menu').classList.add('hidden');
  $('settings-panel').classList.add('hidden');
  $('hud').classList.add('hidden');
  $('mobile-controls').classList.add('hidden');
  $('main-menu').classList.remove('hidden');
  resetPlayer();
}

function openSettings(from) {
  state.previousPanel = from;
  $('settings-panel').classList.remove('hidden');
}

function closeSettings() {
  $('settings-panel').classList.add('hidden');
}

$('start-button').addEventListener('click', startGame);
$('pause-button').addEventListener('click', pauseGame);
$('resume-button').addEventListener('click', resumeGame);
$('main-menu-button').addEventListener('click', returnToMenu);
$('menu-settings-button').addEventListener('click', () => openSettings('main'));
$('pause-settings-button').addEventListener('click', () => openSettings('pause'));
$('close-settings-button').addEventListener('click', closeSettings);
$('controls-button').addEventListener('click', () => $('controls-panel').classList.remove('hidden'));
$('close-controls-button').addEventListener('click', () => $('controls-panel').classList.add('hidden'));

window.addEventListener('keydown', (event) => {
  if (event.code === 'Escape') {
    if (!$('controls-panel').classList.contains('hidden')) {
      $('controls-panel').classList.add('hidden');
    } else if (!$('settings-panel').classList.contains('hidden')) {
      closeSettings();
    } else if (state.mode === 'running') {
      pauseGame();
    } else if (state.mode === 'paused') {
      resumeGame();
    }
  }
});

$('quality-select').addEventListener('change', (event) => {
  const quality = event.target.value;
  const dpr = window.devicePixelRatio || 1;
  if (quality === 'low') {
    renderer.setPixelRatio(Math.min(dpr, 1.0));
    renderer.shadowMap.enabled = false;
    renderer.toneMappingExposure = 1.03;
  } else if (quality === 'high') {
    renderer.setPixelRatio(Math.min(dpr, 2.0));
    renderer.shadowMap.enabled = true;
    renderer.toneMappingExposure = 1.08;
  } else {
    renderer.setPixelRatio(Math.min(dpr, 1.5));
    renderer.shadowMap.enabled = true;
    renderer.toneMappingExposure = 1.06;
  }
  renderer.setSize(window.innerWidth, window.innerHeight);
  showToast(`গ্রাফিক্স: ${quality.toUpperCase()}`);
});

$('camera-sensitivity').addEventListener('input', (event) => {
  controls.cameraSensitivity = Number(event.target.value);
});

window.addEventListener('resize', () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
  const quality = $('quality-select').value;
  const cap = quality === 'high' ? 2 : quality === 'medium' ? 1.5 : 1;
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, cap));
});

function updateLocationLabel() {
  const { x, z } = player.position;
  let name = 'DOWNTOWN';
  if (x > 7 && x < 37 && z > 7 && z < 37) name = 'CENTRAL PARK';
  else if (z < -48) name = 'NORTH DISTRICT';
  else if (z > 48) name = 'SOUTH DISTRICT';
  else if (x < -48) name = 'WEST END';
  else if (x > 48) name = 'EAST QUARTER';
  $('location-name').textContent = name;
}

function animate(now) {
  requestAnimationFrame(animate);
  const delta = Math.min((now - state.lastFrame) / 1000, 0.05);
  state.lastFrame = now;
  if (state.mode === 'running') {
    const input = controls.getInput();
    player.update(delta, input, controls.cameraYaw);
    updateLocationLabel();
  }
  updateCamera(delta || 0.016);
  renderer.render(scene, camera);
}

// The loading panel is kept briefly so first-time shader compilation does not flash.
requestAnimationFrame(animate);
window.setTimeout(() => {
  const loading = $('loading-screen');
  loading.style.opacity = '0';
  window.setTimeout(() => loading.remove(), 480);
}, 650);
