export class GameControls {
  constructor(canvas, elements) {
    this.canvas = canvas;
    this.keys = new Set();
    this.joystick = { x: 0, y: 0, active: false, pointerId: null };
    this.runHeld = false;
    this.jumpQueued = false;
    this.look = { active: false, pointerId: null, lastX: 0, lastY: 0 };
    this.cameraYaw = 0;
    this.cameraPitch = 0.28;
    this.cameraDistance = 7.5;
    this.cameraSensitivity = 1;
    this.elements = elements;
    this.isCoarse = window.matchMedia('(pointer: coarse)').matches || navigator.maxTouchPoints > 0;

    this.onKeyDown = (event) => {
      if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(event.code)) event.preventDefault();
      this.keys.add(event.code);
      if (event.code === 'Space' && !event.repeat) this.jumpQueued = true;
    };
    this.onKeyUp = (event) => this.keys.delete(event.code);
    window.addEventListener('keydown', this.onKeyDown, { passive: false });
    window.addEventListener('keyup', this.onKeyUp);
    window.addEventListener('blur', () => { this.keys.clear(); this.runHeld = false; this.resetJoystick(); });

    this.bindLookControls();
    this.bindJoystick();
    this.bindActionButtons();
  }

  bindLookControls() {
    this.canvas.addEventListener('pointerdown', (event) => {
      if (event.button !== 0 && event.pointerType === 'mouse') return;
      this.look.active = true;
      this.look.pointerId = event.pointerId;
      this.look.lastX = event.clientX;
      this.look.lastY = event.clientY;
      if (this.canvas.setPointerCapture) this.canvas.setPointerCapture(event.pointerId);
    });
    this.canvas.addEventListener('pointermove', (event) => {
      if (!this.look.active || event.pointerId !== this.look.pointerId) return;
      const dx = event.clientX - this.look.lastX;
      const dy = event.clientY - this.look.lastY;
      this.look.lastX = event.clientX;
      this.look.lastY = event.clientY;
      const sensitivity = 0.0042 * this.cameraSensitivity;
      this.cameraYaw -= dx * sensitivity;
      this.cameraPitch = Math.max(-0.08, Math.min(0.88, this.cameraPitch + dy * sensitivity));
    });
    const stopLook = (event) => {
      if (event.pointerId === this.look.pointerId) {
        this.look.active = false;
        this.look.pointerId = null;
      }
    };
    this.canvas.addEventListener('pointerup', stopLook);
    this.canvas.addEventListener('pointercancel', stopLook);
    this.canvas.addEventListener('lostpointercapture', stopLook);
    this.canvas.addEventListener('wheel', (event) => {
      event.preventDefault();
      this.cameraDistance = Math.max(4.2, Math.min(12.5, this.cameraDistance + Math.sign(event.deltaY) * 0.65));
    }, { passive: false });
  }

  bindJoystick() {
    const base = this.elements.joystickBase;
    const thumb = this.elements.joystickThumb;
    if (!base || !thumb) return;
    const update = (event) => {
      const rect = base.getBoundingClientRect();
      const centerX = rect.left + rect.width / 2;
      const centerY = rect.top + rect.height / 2;
      const max = rect.width * 0.34;
      let dx = event.clientX - centerX;
      let dy = event.clientY - centerY;
      const length = Math.hypot(dx, dy);
      if (length > max) { dx = dx / length * max; dy = dy / length * max; }
      this.joystick.x = dx / max;
      this.joystick.y = -dy / max;
      thumb.style.transform = `translate(${dx}px, ${dy}px)`;
    };
    base.addEventListener('pointerdown', (event) => {
      event.preventDefault();
      this.joystick.active = true;
      this.joystick.pointerId = event.pointerId;
      base.setPointerCapture(event.pointerId);
      update(event);
    });
    base.addEventListener('pointermove', (event) => {
      if (!this.joystick.active || event.pointerId !== this.joystick.pointerId) return;
      event.preventDefault();
      update(event);
    });
    const stop = (event) => {
      if (event.pointerId === this.joystick.pointerId) this.resetJoystick();
    };
    base.addEventListener('pointerup', stop);
    base.addEventListener('pointercancel', stop);
    base.addEventListener('lostpointercapture', stop);
  }

  bindActionButtons() {
    const jump = this.elements.jumpButton;
    const run = this.elements.runButton;
    if (jump) {
      jump.addEventListener('pointerdown', (event) => { event.preventDefault(); this.jumpQueued = true; });
    }
    if (run) {
      run.addEventListener('pointerdown', (event) => { event.preventDefault(); this.runHeld = true; run.classList.add('pressed'); });
      const stop = () => { this.runHeld = false; run.classList.remove('pressed'); };
      run.addEventListener('pointerup', stop);
      run.addEventListener('pointercancel', stop);
      run.addEventListener('lostpointercapture', stop);
      run.addEventListener('pointerleave', stop);
    }
  }

  resetJoystick() {
    this.joystick.active = false;
    this.joystick.pointerId = null;
    this.joystick.x = 0;
    this.joystick.y = 0;
    if (this.elements.joystickThumb) this.elements.joystickThumb.style.transform = 'translate(0, 0)';
  }

  getInput() {
    let x = 0;
    let y = 0;
    if (this.keys.has('KeyA') || this.keys.has('ArrowLeft')) x -= 1;
    if (this.keys.has('KeyD') || this.keys.has('ArrowRight')) x += 1;
    if (this.keys.has('KeyW') || this.keys.has('ArrowUp')) y += 1;
    if (this.keys.has('KeyS') || this.keys.has('ArrowDown')) y -= 1;
    if (this.joystick.active) {
      x = this.joystick.x;
      y = this.joystick.y;
    }
    const jump = this.jumpQueued;
    this.jumpQueued = false;
    return {
      x,
      y,
      run: this.runHeld || this.keys.has('ShiftLeft') || this.keys.has('ShiftRight'),
      jump,
    };
  }

  dispose() {
    window.removeEventListener('keydown', this.onKeyDown);
    window.removeEventListener('keyup', this.onKeyUp);
  }
}
