import * as THREE from 'three';

function smoothAngle(current, target, amount) {
  const delta = Math.atan2(Math.sin(target - current), Math.cos(target - current));
  return current + delta * amount;
}

export class Player {
  constructor(scene, colliders) {
    this.scene = scene;
    this.colliders = colliders;
    this.position = new THREE.Vector3(6, 0, 12);
    this.velocity = new THREE.Vector3();
    this.verticalVelocity = 0;
    this.grounded = true;
    this.radius = 0.58;
    this.walkSpeed = 5.1;
    this.runSpeed = 8.2;
    this.group = this.createCharacter();
    this.group.position.copy(this.position);
    this.scene.add(this.group);
    this.elapsed = 0;
  }

  createCharacter() {
    const group = new THREE.Group();
    const skin = new THREE.MeshStandardMaterial({ color: 0xb97855, roughness: 0.88 });
    const shirt = new THREE.MeshStandardMaterial({ color: 0x1b7d83, roughness: 0.82 });
    const darkShirt = new THREE.MeshStandardMaterial({ color: 0x15585e, roughness: 0.88 });
    const pants = new THREE.MeshStandardMaterial({ color: 0x263340, roughness: 0.9 });
    const shoes = new THREE.MeshStandardMaterial({ color: 0x101922, roughness: 0.95 });
    const hair = new THREE.MeshStandardMaterial({ color: 0x1a1b20, roughness: 0.95 });

    const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.42, 0.72, 4, 8), shirt);
    torso.position.y = 1.38;
    torso.castShadow = true;
    group.add(torso);

    const collar = new THREE.Mesh(new THREE.TorusGeometry(0.24, 0.055, 5, 10), darkShirt);
    collar.rotation.x = Math.PI / 2;
    collar.position.set(0, 1.72, -0.005);
    group.add(collar);

    const head = new THREE.Mesh(new THREE.SphereGeometry(0.30, 12, 10), skin);
    head.position.set(0, 2.12, 0);
    head.scale.set(0.92, 1.08, 0.9);
    head.castShadow = true;
    group.add(head);

    const hairCap = new THREE.Mesh(new THREE.SphereGeometry(0.305, 12, 8, 0, Math.PI * 2, 0, Math.PI * 0.55), hair);
    hairCap.position.set(0, 2.20, -0.015);
    hairCap.scale.set(1, 0.82, 0.98);
    group.add(hairCap);

    const leftLeg = new THREE.Group();
    const rightLeg = new THREE.Group();
    [-1, 1].forEach((side) => {
      const legPivot = side < 0 ? leftLeg : rightLeg;
      legPivot.position.set(side * 0.17, 0.9, 0);
      const leg = new THREE.Mesh(new THREE.CapsuleGeometry(0.14, 0.48, 3, 7), pants);
      leg.position.y = -0.28;
      leg.castShadow = true;
      legPivot.add(leg);
      const shoe = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.14, 0.43), shoes);
      shoe.position.set(0, -0.56, -0.09);
      legPivot.add(shoe);
    });
    group.add(leftLeg, rightLeg);

    const leftArm = new THREE.Group();
    const rightArm = new THREE.Group();
    [-1, 1].forEach((side) => {
      const armPivot = side < 0 ? leftArm : rightArm;
      armPivot.position.set(side * 0.48, 1.65, 0);
      const sleeve = new THREE.Mesh(new THREE.CapsuleGeometry(0.135, 0.34, 3, 7), shirt);
      sleeve.position.y = -0.22;
      sleeve.rotation.z = side * -0.12;
      sleeve.castShadow = true;
      armPivot.add(sleeve);
      const hand = new THREE.Mesh(new THREE.SphereGeometry(0.13, 8, 7), skin);
      hand.position.y = -0.52;
      armPivot.add(hand);
    });
    group.add(leftArm, rightArm);

    group.userData.parts = { leftLeg, rightLeg, leftArm, rightArm, torso };
    return group;
  }

  collidesAt(x, z) {
    const limit = 108;
    if (x < -limit || x > limit || z < -limit || z > limit) return true;
    for (const box of this.colliders) {
      const closestX = Math.max(box.minX, Math.min(x, box.maxX));
      const closestZ = Math.max(box.minZ, Math.min(z, box.maxZ));
      const dx = x - closestX;
      const dz = z - closestZ;
      if (dx * dx + dz * dz < this.radius * this.radius) return true;
    }
    return false;
  }

  update(delta, input, cameraYaw) {
    const dt = Math.min(delta, 0.04);
    this.elapsed += dt;

    const inputLength = Math.hypot(input.x, input.y);
    let directionX = 0;
    let directionZ = 0;
    if (inputLength > 0.04) {
      const ix = input.x / Math.max(1, inputLength);
      const iy = input.y / Math.max(1, inputLength);
      const forwardX = -Math.sin(cameraYaw);
      const forwardZ = -Math.cos(cameraYaw);
      const rightX = Math.cos(cameraYaw);
      const rightZ = -Math.sin(cameraYaw);
      directionX = rightX * ix + forwardX * iy;
      directionZ = rightZ * ix + forwardZ * iy;
      const directionLength = Math.hypot(directionX, directionZ) || 1;
      directionX /= directionLength;
      directionZ /= directionLength;
    }

    const targetSpeed = input.run ? this.runSpeed : this.walkSpeed;
    const targetVX = directionX * targetSpeed;
    const targetVZ = directionZ * targetSpeed;
    const smoothing = 1 - Math.exp(-11 * dt);
    this.velocity.x += (targetVX - this.velocity.x) * smoothing;
    this.velocity.z += (targetVZ - this.velocity.z) * smoothing;
    if (inputLength <= 0.04) {
      this.velocity.x *= Math.exp(-8 * dt);
      this.velocity.z *= Math.exp(-8 * dt);
    }

    const nextX = this.position.x + this.velocity.x * dt;
    if (!this.collidesAt(nextX, this.position.z)) this.position.x = nextX;
    else this.velocity.x = 0;
    const nextZ = this.position.z + this.velocity.z * dt;
    if (!this.collidesAt(this.position.x, nextZ)) this.position.z = nextZ;
    else this.velocity.z = 0;

    if (input.jump && this.grounded) {
      this.verticalVelocity = 7.2;
      this.grounded = false;
    }
    if (!this.grounded) {
      this.verticalVelocity -= 19.5 * dt;
      this.position.y += this.verticalVelocity * dt;
      if (this.position.y <= 0) {
        this.position.y = 0;
        this.verticalVelocity = 0;
        this.grounded = true;
      }
    }

    const moving = Math.hypot(this.velocity.x, this.velocity.z) > 0.45;
    if (moving) {
      const targetYaw = Math.atan2(-directionX, -directionZ);
      this.group.rotation.y = smoothAngle(this.group.rotation.y, targetYaw, 1 - Math.exp(-13 * dt));
    }

    const parts = this.group.userData.parts;
    const stride = moving ? Math.min(1.4, Math.hypot(this.velocity.x, this.velocity.z) / this.walkSpeed) : 0;
    const swing = Math.sin(this.elapsed * (input.run ? 12.5 : 9.2)) * stride * 0.62;
    parts.leftLeg.rotation.x = swing;
    parts.rightLeg.rotation.x = -swing;
    parts.leftArm.rotation.x = -swing * 0.72;
    parts.rightArm.rotation.x = swing * 0.72;
    parts.torso.position.y = 1.38 + (moving ? Math.abs(Math.sin(this.elapsed * 9)) * 0.035 * stride : 0);

    this.group.position.set(this.position.x, this.position.y, this.position.z);
  }
}
