import * as THREE from 'three';

const ROAD_COORDS = [-88, -44, 0, 44, 88];
const CITY_SIZE = 230;

function mulberry32(seed) {
  return function () {
    let t = (seed += 0x6D2B79F5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export class CityWorld {
  constructor(scene) {
    this.scene = scene;
    this.colliders = [];
    this.random = mulberry32(18427);
    this.materials = this.createMaterials();
    this.windowInstances = [];
    this.createLighting();
    this.createGround();
    this.createRoadNetwork();
    this.createCityBlocks();
    this.createStreetFurniture();
    this.createPark();
    this.flushWindows();
    this.createSkylineDetails();
  }

  createMaterials() {
    const make = (color, roughness = 0.85, metalness = 0.05) => new THREE.MeshStandardMaterial({ color, roughness, metalness });
    return {
      ground: make(0x52645d),
      road: make(0x252f39, 0.98),
      sidewalk: make(0x8b9696, 0.92),
      curb: make(0xb5b9b3),
      lane: make(0xe7ddaa, 0.8),
      whiteLine: make(0xd7e1df, 0.8),
      grass: make(0x3d7458),
      treeTrunk: make(0x60452f),
      treeLeaf: make(0x2c7958),
      treeLeaf2: make(0x3b8a62),
      lamp: make(0x36434b, 0.58, 0.45),
      lampGlow: new THREE.MeshBasicMaterial({ color: 0xffedc1 }),
      parkPath: make(0xb8b8a4),
      bench: make(0x69503e),
      building: [0x71828a, 0x8a9295, 0x667b86, 0x9c9990, 0x596c79, 0x89827a].map((c) => make(c, 0.72, 0.16)),
      roof: make(0x3c4c56, 0.78, 0.18),
      glass: new THREE.MeshStandardMaterial({ color: 0x5a9aab, roughness: 0.27, metalness: 0.45, emissive: 0x12303b, emissiveIntensity: 0.16 }),
      litGlass: new THREE.MeshStandardMaterial({ color: 0xf0ca81, roughness: 0.34, metalness: 0.16, emissive: 0x9c6323, emissiveIntensity: 0.25 }),
      sign: make(0x133c48, 0.55, 0.3),
    };
  }

  createLighting() {
    this.scene.background = new THREE.Color(0x9ab9c7);
    this.scene.fog = new THREE.Fog(0x9ab9c7, 95, 245);
    const hemi = new THREE.HemisphereLight(0xe5f6ff, 0x58634d, 2.0);
    this.scene.add(hemi);
    const sun = new THREE.DirectionalLight(0xffedcf, 3.1);
    sun.position.set(-65, 105, 45);
    sun.castShadow = true;
    sun.shadow.mapSize.set(1536, 1536);
    sun.shadow.camera.left = -125;
    sun.shadow.camera.right = 125;
    sun.shadow.camera.top = 125;
    sun.shadow.camera.bottom = -125;
    sun.shadow.camera.near = 1;
    sun.shadow.camera.far = 260;
    sun.shadow.bias = -0.00025;
    this.scene.add(sun);
  }

  createGround() {
    const ground = new THREE.Mesh(new THREE.PlaneGeometry(CITY_SIZE, CITY_SIZE), this.materials.ground);
    ground.rotation.x = -Math.PI / 2;
    ground.position.y = -0.16;
    ground.receiveShadow = true;
    this.scene.add(ground);
  }

  addBox(width, height, depth, material, x, y, z, castShadow = false) {
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(width, height, depth), material);
    mesh.position.set(x, y, z);
    mesh.castShadow = castShadow;
    mesh.receiveShadow = true;
    this.scene.add(mesh);
    return mesh;
  }

  createRoadNetwork() {
    const roadWidth = 14;
    const whiteMarks = [];
    const yellowMarks = [];
    ROAD_COORDS.forEach((coord) => {
      this.addBox(roadWidth, 0.12, CITY_SIZE, this.materials.road, coord, -0.035, 0);
      this.addBox(CITY_SIZE, 0.12, roadWidth, this.materials.road, 0, -0.035, coord);

      [-1, 1].forEach((side) => {
        this.addBox(1.4, 0.25, CITY_SIZE, this.materials.sidewalk, coord + side * 8.1, 0.02, 0);
        this.addBox(CITY_SIZE, 0.25, 1.4, this.materials.sidewalk, 0, 0.02, coord + side * 8.1);
        this.addBox(0.22, 0.28, CITY_SIZE, this.materials.curb, coord + side * 7.3, 0.08, 0);
        this.addBox(CITY_SIZE, 0.28, 0.22, this.materials.curb, 0, 0.08, coord + side * 7.3);
      });

      for (let p = -108; p <= 108; p += 13) {
        if (Math.abs(p - coord) < 11) continue;
        whiteMarks.push([coord - 3.45, 0.035, p, 0], [coord + 3.45, 0.035, p, 0]);
        whiteMarks.push([p, 0.035, coord - 3.45, Math.PI / 2], [p, 0.035, coord + 3.45, Math.PI / 2]);
      }
      for (let p = -107; p <= 107; p += 12) {
        if (Math.abs(p - coord) < 10) continue;
        yellowMarks.push([coord - 0.14, 0.04, p, 0], [coord + 0.14, 0.04, p, 0]);
        yellowMarks.push([p, 0.04, coord - 0.14, Math.PI / 2], [p, 0.04, coord + 0.14, Math.PI / 2]);
      }
    });

    this.addInstancedMarkings(new THREE.BoxGeometry(0.16, 0.025, 5.2), this.materials.whiteLine, whiteMarks);
    this.addInstancedMarkings(new THREE.BoxGeometry(0.13, 0.027, 5.0), this.materials.lane, yellowMarks);

    // Wide pedestrian crossing bars around the central intersection.
    for (let i = -3; i <= 3; i++) {
      if (i === 0) continue;
      this.addBox(1.0, 0.035, 5.7, this.materials.whiteLine, i * 1.45, 0.045, -9.4);
      this.addBox(1.0, 0.035, 5.7, this.materials.whiteLine, i * 1.45, 0.045, 9.4);
      this.addBox(5.7, 0.035, 1.0, this.materials.whiteLine, -9.4, 0.045, i * 1.45);
      this.addBox(5.7, 0.035, 1.0, this.materials.whiteLine, 9.4, 0.045, i * 1.45);
    }
  }


  addInstancedMarkings(geometry, material, items) {
    if (!items.length) return;
    const batch = new THREE.InstancedMesh(geometry, material, items.length);
    const dummy = new THREE.Object3D();
    items.forEach(([x, y, z, rotation], index) => {
      dummy.position.set(x, y, z);
      dummy.rotation.set(0, rotation, 0);
      dummy.updateMatrix();
      batch.setMatrixAt(index, dummy.matrix);
    });
    batch.instanceMatrix.needsUpdate = true;
    batch.receiveShadow = true;
    this.scene.add(batch);
  }

  createCityBlocks() {
    const blocks = [-66, -22, 22, 66];
    blocks.forEach((x, ix) => {
      blocks.forEach((z, iz) => {
        if (ix === 2 && iz === 2) return; // reserved for the central park
        const mainWidth = 11 + this.random() * 5;
        const mainDepth = 11 + this.random() * 5;
        const height = 13 + this.random() * 43;
        const offsetX = (this.random() - 0.5) * 3.5;
        const offsetZ = (this.random() - 0.5) * 3.5;
        this.createBuilding(x + offsetX, z + offsetZ, mainWidth, mainDepth, height);

        if (this.random() > 0.42) {
          const sx = x + (this.random() > 0.5 ? 8.0 : -8.0);
          const sz = z + (this.random() > 0.5 ? 7.0 : -7.0);
          this.createBuilding(sx, sz, 7 + this.random() * 2.5, 7 + this.random() * 2.5, 8 + this.random() * 18, true);
        }
      });
    });

  }

  createBuilding(x, z, width, depth, height, small = false, landmark = false) {
    const material = this.materials.building[Math.floor(this.random() * this.materials.building.length)];
    const base = this.addBox(width, height, depth, material, x, height / 2, z, true);
    base.castShadow = true;
    const roofHeight = landmark ? 1.1 : 0.55;
    this.addBox(width + 0.35, roofHeight, depth + 0.35, this.materials.roof, x, height + roofHeight / 2, z, true);

    // Recessed-looking windows are batched into two InstancedMeshes after the city is built.
    const columnsX = Math.max(2, Math.floor(width / 2.6));
    const columnsZ = Math.max(2, Math.floor(depth / 2.6));
    const floors = Math.max(2, Math.floor((height - 3) / 3.4));
    const frontZ = z + depth / 2 + 0.055;
    const backZ = z - depth / 2 - 0.055;
    for (let floor = 0; floor < floors; floor++) {
      const y = 2.1 + floor * 3.35;
      if (y > height - 1.8) break;
      for (let col = 0; col < columnsX; col++) {
        const wx = x - width / 2 + ((col + 0.5) * width) / columnsX;
        this.queueWindow(wx, y, frontZ, 0, this.random() > 0.76);
        this.queueWindow(wx, y, backZ, Math.PI, this.random() > 0.76);
      }
      for (let col = 0; col < columnsZ; col++) {
        const wz = z - depth / 2 + ((col + 0.5) * depth) / columnsZ;
        this.queueWindow(x + width / 2 + 0.055, y, wz, Math.PI / 2, this.random() > 0.76);
        this.queueWindow(x - width / 2 - 0.055, y, wz, -Math.PI / 2, this.random() > 0.76);
      }
    }

    if (landmark) {
      this.addBox(1.0, 3.5, 1.0, this.materials.roof, x + width * 0.28, height + 2.25, z - depth * 0.22, true);
    }
    if (!small && this.random() > 0.55) {
      // A subtle rooftop service unit.
      this.addBox(width * 0.25, 1.4, depth * 0.22, this.materials.roof, x - width * 0.2, height + 1.1, z, true);
    }
    this.colliders.push({ minX: x - width / 2, maxX: x + width / 2, minZ: z - depth / 2, maxZ: z + depth / 2 });
  }

  queueWindow(x, y, z, rotationY, lit) {
    this.windowInstances.push({ x, y, z, rotationY, materialIndex: lit ? 1 : 0 });
  }

  flushWindows() {
    const geometry = new THREE.BoxGeometry(1.25, 1.52, 0.075);
    [0, 1].forEach((index) => {
      const items = this.windowInstances.filter((item) => item.materialIndex === index);
      if (!items.length) return;
      const batch = new THREE.InstancedMesh(geometry, index === 1 ? this.materials.litGlass : this.materials.glass, items.length);
      const dummy = new THREE.Object3D();
      items.forEach((item, i) => {
        dummy.position.set(item.x, item.y, item.z);
        dummy.rotation.set(0, item.rotationY, 0);
        dummy.updateMatrix();
        batch.setMatrixAt(i, dummy.matrix);
      });
      batch.instanceMatrix.needsUpdate = true;
      batch.castShadow = false;
      batch.receiveShadow = true;
      this.scene.add(batch);
    });
    this.windowInstances.length = 0;
  }

  createTree(x, z, scale = 1) {
    const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.18 * scale, 0.25 * scale, 2.2 * scale, 7), this.materials.treeTrunk);
    trunk.position.set(x, 1.1 * scale, z);
    trunk.castShadow = true;
    this.scene.add(trunk);
    const leaves = new THREE.Mesh(new THREE.SphereGeometry(1.45 * scale, 8, 7), this.random() > 0.5 ? this.materials.treeLeaf : this.materials.treeLeaf2);
    leaves.position.set(x, 3.0 * scale, z);
    leaves.scale.set(1, 1.12, 1);
    leaves.castShadow = true;
    this.scene.add(leaves);
  }

  createStreetFurniture() {
    ROAD_COORDS.forEach((road) => {
      [-1, 1].forEach((side) => {
        for (let p = -96; p <= 96; p += 32) {
          if (Math.abs(p - road) < 12) continue;
          this.createStreetLamp(road + side * 9.4, p, false);
          this.createTree(road + side * 10.5, p + 8, 0.72);
        }
      });
    });

    // A small transit / shopping sign near the southern avenue.
    this.addBox(0.35, 3.2, 0.35, this.materials.lamp, 14, 1.6, -94, false);
    this.addBox(4.8, 1.2, 0.18, this.materials.sign, 14, 3.15, -94, false);
  }

  createStreetLamp(x, z, park = false) {
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.1, 5.4, 6), this.materials.lamp);
    pole.position.set(x, 2.7, z);
    pole.castShadow = true;
    this.scene.add(pole);
    const arm = new THREE.Mesh(new THREE.BoxGeometry(0.95, 0.09, 0.09), this.materials.lamp);
    arm.position.set(x + 0.38, 5.15, z);
    this.scene.add(arm);
    const glow = new THREE.Mesh(new THREE.SphereGeometry(0.16, 7, 6), this.materials.lampGlow);
    glow.position.set(x + 0.78, 5.08, z);
    this.scene.add(glow);
  }

  createPark() {
    const x = 22; const z = 22;
    this.addBox(27, 0.22, 27, this.materials.grass, x, 0.015, z);
    this.addBox(3.0, 0.04, 25, this.materials.parkPath, x, 0.15, z);
    this.addBox(25, 0.04, 3.0, this.materials.parkPath, x, 0.15, z);
    [[-9, -9], [9, -9], [-9, 9], [9, 9], [-9, 0], [9, 0], [0, -9], [0, 9]].forEach(([dx, dz], i) => {
      this.createTree(x + dx, z + dz, i % 3 === 0 ? 0.9 : 0.72);
    });
    [-5, 5].forEach((dx) => {
      this.addBox(2.4, 0.18, 0.5, this.materials.bench, x + dx, 0.55, z + 4.8, true);
      this.addBox(0.18, 0.5, 0.45, this.materials.lamp, x + dx - 0.8, 0.28, z + 4.8);
      this.addBox(0.18, 0.5, 0.45, this.materials.lamp, x + dx + 0.8, 0.28, z + 4.8);
    });
  }

  createSkylineDetails() {
    // A low retaining wall around the playable city keeps the horizon intentional.
    const boundaryMat = new THREE.MeshStandardMaterial({ color: 0x46565c, roughness: 0.9 });
    this.addBox(CITY_SIZE, 2.2, 1.2, boundaryMat, 0, 0.9, -CITY_SIZE / 2 + 1);
    this.addBox(CITY_SIZE, 2.2, 1.2, boundaryMat, 0, 0.9, CITY_SIZE / 2 - 1);
    this.addBox(1.2, 2.2, CITY_SIZE, boundaryMat, -CITY_SIZE / 2 + 1, 0.9, 0);
    this.addBox(1.2, 2.2, CITY_SIZE, boundaryMat, CITY_SIZE / 2 - 1, 0.9, 0);
  }
}
