# METRO LEGENDS: CITY OF DREAMS — Phase 1

An original, browser-playable 3D city prototype built with HTML, CSS, JavaScript, Three.js, and Vite. It uses procedural geometry and original placeholder design; it does not include GTA assets or code.

## Phase 1 features

- Procedurally generated modern city blocks, roads, sidewalks, street markings, trees, street lamps, and a small park
- Third-person player character built from Three.js geometry
- Walking, running, jumping, and animated limbs
- Mouse-drag camera rotation and mouse-wheel camera zoom
- Keyboard controls and Android-friendly virtual joystick / touch buttons
- Basic player-to-building collision and city boundary limits
- Main menu, controls guide, pause/resume, graphics settings, and camera sensitivity
- Responsive desktop and mobile layout

## Requirements

- Node.js 20.19+ or 22.12+
- npm (installed with Node.js)
- A modern browser with WebGL support

## Run on a computer

1. Extract the ZIP file.
2. Open the extracted `metro-legends-phase1` folder in VS Code (or another code editor).
3. Open a terminal in that folder.
4. Run:

   ```bash
   npm install
   npm run dev
   ```

5. Open the local address printed by Vite, usually `http://localhost:5173`.

To make a production build:

```bash
npm run build
npm run preview
```

The deployable website files are generated in the `dist/` folder after `npm run build`.

## Controls

### PC

| Action | Control |
|---|---|
| Move | W A S D or arrow keys |
| Run | Hold Shift |
| Jump | Space |
| Rotate camera | Drag with mouse on the game view |
| Zoom camera | Mouse wheel |
| Pause / resume | Esc or pause button |

### Android / touchscreen

- Use the virtual joystick on the lower-left side to move.
- Hold **RUN** to run.
- Tap **JUMP** to jump.
- Drag on the open game view to rotate the camera.
- Use the pause button at the top-right.

## Project structure

```text
metro-legends-phase1/
├── index.html
├── package.json
├── README.md
└── src/
    ├── main.js       # App startup, renderer, camera, UI, game loop
    ├── world.js      # Procedural city, roads, buildings, props, collision boxes
    ├── player.js     # Third-person character, movement, jumping, collision
    ├── controls.js   # Keyboard, mouse, virtual joystick, touch buttons
    └── style.css     # Menu, HUD, modal panels, mobile-responsive layout
```

## Deploy

Run `npm run build`, then upload the **contents of the `dist/` folder** to a static hosting provider such as Netlify, Cloudflare Pages, or GitHub Pages. For Vite hosting, use `npm run build` as the build command and `dist` as the publish directory.

## Current scope

This is Phase 1, a playable city-and-character foundation. Vehicle driving, traffic, pedestrians, campaign missions, police pursuit, minimap, and weather/audio systems are intentionally reserved for later phases so the base project stays testable and expandable.

### Test on an Android phone (same Wi-Fi)

1. Start the development server on your computer with `npm run dev` (the included Vite script listens on the network).
2. Find your computer's local IPv4 address (for example, `192.168.0.25`).
3. On the phone, open `http://192.168.0.25:5173` using Chrome. Replace the example IP with your own computer's IP.
4. Keep both devices connected to the same Wi-Fi network. Your firewall may ask permission to allow the development server.

You can also deploy the `dist/` output to a web host and open that published website on Android.
